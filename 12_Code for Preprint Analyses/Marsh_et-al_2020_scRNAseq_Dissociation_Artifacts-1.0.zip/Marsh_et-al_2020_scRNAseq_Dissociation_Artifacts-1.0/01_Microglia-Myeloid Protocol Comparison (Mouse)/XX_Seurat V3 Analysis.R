# Upgrade object to Seurat V3
exp17_micro_ALL <- UpdateSeuratObject(object = exp17_micro_ALL)