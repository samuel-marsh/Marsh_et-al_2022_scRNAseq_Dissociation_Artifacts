#### Download Seuart V2.3.4 from CRAN archive ####
# In terminal navigate to desired directory and enter command
wget https://cran.r-project.org/src/contrib/Archive/Seurat/Seurat_2.3.4.tar.gz

# In R/RStudio use following command:
install.packages("/PATH_TO_DOWNLOAD/Seurat_2.3.4.tar.gz", repos = NULL, type = "source")
